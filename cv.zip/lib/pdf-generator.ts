// Dynamic imports will be used instead of static imports

interface PDFGeneratorOptions {
  language: string
  onProgress?: (message: string) => void
}

export const generatePDF = async ({ language, onProgress }: PDFGeneratorOptions) => {
  // Import html2canvas and jsPDF dynamically
  const html2canvas = (await import("html2canvas")).default
  const jsPDF = (await import("jspdf")).default

  // A4 dimensions in pixels at 300 DPI for high quality
  const A4_WIDTH_PX = 2480
  const A4_HEIGHT_PX = 3508

  // A4 dimensions in mm for jsPDF
  const A4_WIDTH_MM = 210
  const A4_HEIGHT_MM = 297

  // Enhanced canvas options for better quality
  const canvasOptions = {
    scale: 3,
    useCORS: true,
    allowTaint: true,
    backgroundColor: "#ffffff",
    width: A4_WIDTH_PX / 3,
    height: A4_HEIGHT_PX / 3,
    scrollX: 0,
    scrollY: 0,
    windowWidth: A4_WIDTH_PX / 3,
    windowHeight: A4_HEIGHT_PX / 3,
    removeContainer: true,
    imageTimeout: 15000,
    logging: false,
  }

  try {
    // Hide control elements during PDF generation
    const controlElements = document.querySelectorAll(".print\\:hidden")
    controlElements.forEach((el) => {
      ;(el as HTMLElement).style.display = "none"
    })

    // Show loading state
    const loadingToast = document.createElement("div")
    loadingToast.className =
      "fixed top-4 left-1/2 transform -translate-x-1/2 bg-sky-500 text-white px-6 py-3 rounded-lg z-50 text-sm font-medium"
    loadingToast.textContent =
      language === "sv" ? "Genererar PDF..." : language === "en" ? "Generating PDF..." : "Создание PDF..."
    document.body.appendChild(loadingToast)

    // Get page elements
    const page1 = document.querySelector('[data-page="1"]') as HTMLElement
    const page2 = document.querySelector('[data-page="2"]') as HTMLElement

    if (!page1 || !page2) {
      throw new Error("Page elements not found")
    }

    // Create PDF with high quality settings
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
      compress: true,
      precision: 16,
    })

    // Capture page 1 with retry mechanism
    let canvas1: HTMLCanvasElement | undefined
    let attempts = 0
    const maxAttempts = 3

    while (attempts < maxAttempts) {
      try {
        canvas1 = await html2canvas(page1, canvasOptions)
        break
      } catch (error) {
        attempts++
        if (attempts === maxAttempts) throw error
        await new Promise((resolve) => setTimeout(resolve, 1000))
      }
    }

    // Add page 1 to PDF with proper scaling
    if (canvas1) {
      const imgData1 = canvas1.toDataURL("image/jpeg", 0.95)
      pdf.addImage(imgData1, "JPEG", 0, 0, A4_WIDTH_MM, A4_HEIGHT_MM, undefined, "FAST")
    }

    // Update loading message
    loadingToast.textContent =
      language === "sv"
        ? "Bearbetar sida 2..."
        : language === "en"
          ? "Processing page 2..."
          : "Обработка страницы 2..."

    // Add new page
    pdf.addPage()

    // Capture page 2 with retry mechanism
    let canvas2: HTMLCanvasElement | undefined
    attempts = 0

    while (attempts < maxAttempts) {
      try {
        canvas2 = await html2canvas(page2, canvasOptions)
        break
      } catch (error) {
        attempts++
        if (attempts === maxAttempts) throw error
        await new Promise((resolve) => setTimeout(resolve, 1000))
      }
    }

    // Add page 2 to PDF with proper scaling
    if (canvas2) {
      const imgData2 = canvas2.toDataURL("image/jpeg", 0.95)
      pdf.addImage(imgData2, "JPEG", 0, 0, A4_WIDTH_MM, A4_HEIGHT_MM, undefined, "FAST")
    }

    // Update loading message
    loadingToast.textContent =
      language === "sv" ? "Slutför PDF..." : language === "en" ? "Finalizing PDF..." : "Завершение PDF..."

    // Generate filename with timestamp
    const timestamp = new Date().toISOString().slice(0, 10)
    const filename = `CV_Vladyslav_Chyzhov_${language.toUpperCase()}_${timestamp}.pdf`

    // Add metadata to PDF
    pdf.setProperties({
      title: `CV - Vladyslav Chyzhov (${language.toUpperCase()})`,
      subject: "Professional Resume",
      author: "Vladyslav Chyzhov",
      creator: "CV Generator",
    })

    // Download PDF
    pdf.save(filename)

    // Success message
    loadingToast.textContent =
      language === "sv" ? "PDF nedladdad!" : language === "en" ? "PDF downloaded!" : "PDF скачан!"
    loadingToast.className = loadingToast.className.replace("bg-sky-500", "bg-green-500")

    // Remove loading toast after delay
    setTimeout(() => {
      if (document.body.contains(loadingToast)) {
        document.body.removeChild(loadingToast)
      }
    }, 2000)

    // Restore control elements
    controlElements.forEach((el) => {
      ;(el as HTMLElement).style.display = ""
    })

    return { success: true, filename }
  } catch (error) {
    console.error("Error generating PDF:", error)

    // Error message
    const errorToast = document.createElement("div")
    errorToast.className =
      "fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-lg z-50 text-sm font-medium"
    errorToast.textContent =
      language === "sv"
        ? "Fel vid PDF-generering"
        : language === "en"
          ? "PDF generation error"
          : "Ошибка создания PDF"
    document.body.appendChild(errorToast)

    setTimeout(() => {
      if (document.body.contains(errorToast)) {
        document.body.removeChild(errorToast)
      }
    }, 3000)

    // Restore control elements in case of error
    const controlElements = document.querySelectorAll(".print\\:hidden")
    controlElements.forEach((el) => {
      ;(el as HTMLElement).style.display = ""
    })

    return { success: false, error: error as Error }
  }
} 