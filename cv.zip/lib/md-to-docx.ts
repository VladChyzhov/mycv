import { Document, Packer, Paragraph, TextRun, HeadingLevel } from "docx"

interface MarkdownToDocxOptions {
  inputPath: string
  outputPath: string
}

export const convertMarkdownToDocx = async ({ inputPath, outputPath }: MarkdownToDocxOptions) => {
  try {
    // Read the markdown file
    const response = await fetch(inputPath)
    const markdownContent = await response.text()

    // Parse markdown content
    const paragraphs = parseMarkdown(markdownContent)

    // Create document
    const doc = new Document({
      sections: [
        {
          properties: {},
          children: paragraphs,
        },
      ],
    })

    // Generate and save the document
    const buffer = await Packer.toBuffer(doc)
    
    // Create download link
    const blob = new Blob([buffer], { 
      type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
    })
    
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = outputPath
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    return { success: true, message: "DOCX file generated successfully" }
  } catch (error) {
    console.error("Error converting markdown to DOCX:", error)
    return { success: false, error: error as Error }
  }
}

const parseMarkdown = (content: string) => {
  const lines = content.split("\n")
  const paragraphs: Paragraph[] = []

  for (const line of lines) {
    const trimmedLine = line.trim()
    
    if (!trimmedLine) {
      // Empty line - add spacing
      paragraphs.push(new Paragraph({}))
      continue
    }

    if (trimmedLine.startsWith("# ")) {
      // H1 heading
      paragraphs.push(
        new Paragraph({
          text: trimmedLine.substring(2),
          heading: HeadingLevel.HEADING_1,
        })
      )
    } else if (trimmedLine.startsWith("## ")) {
      // H2 heading
      paragraphs.push(
        new Paragraph({
          text: trimmedLine.substring(3),
          heading: HeadingLevel.HEADING_2,
        })
      )
    } else if (trimmedLine.startsWith("### ")) {
      // H3 heading
      paragraphs.push(
        new Paragraph({
          text: trimmedLine.substring(4),
          heading: HeadingLevel.HEADING_3,
        })
      )
    } else if (trimmedLine.startsWith("- ")) {
      // Bullet point
      paragraphs.push(
        new Paragraph({
          text: trimmedLine.substring(2),
          bullet: {
            level: 0,
          },
        })
      )
    } else if (trimmedLine.startsWith("  - ")) {
      // Nested bullet point
      paragraphs.push(
        new Paragraph({
          text: trimmedLine.substring(4),
          bullet: {
            level: 1,
          },
        })
      )
    } else {
      // Regular paragraph
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({
              text: trimmedLine,
              size: 24, // 12pt
            }),
          ],
        })
      )
    }
  }

  return paragraphs
}

// Function to convert CV markdown to DOCX
export const convertCVToDocx = async () => {
  return await convertMarkdownToDocx({
    inputPath: "/cv.md",
    outputPath: "CV_Vladyslav_Chyzhov.docx"
  })
} 