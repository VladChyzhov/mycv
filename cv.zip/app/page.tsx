"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { generatePDF } from "@/lib/pdf-generator"
import { convertCVToDocx } from "@/lib/md-to-docx"
import {
  Phone,
  Mail,
  MapPin,
  Download,
  Globe,
  Languages,
  Upload,
  Star,
  Briefcase,
  GraduationCap,
  User,
  Heart,
  Camera,
  Plane,
  Music,
  Code,
  Brain,
  Circle,
  Users,
  Activity,
  BookOpen,
} from "lucide-react"

const translations = {
  ru: {
    name: "Владислав Чижов",
    title: "Предприниматель и экономист",
    downloadPdf: "Скачать PDF",
    statement: "РЕЗЮМЕ",
    workExperience: "ОПЫТ РАБОТЫ",
    education: "ОБРАЗОВАНИЕ",
    proSkills: "ПРОФЕССИОНАЛЬНЫЕ НАВЫКИ",
    personalSkills: "ЛИЧНЫЕ КАЧЕСТВА",
    hobbies: "ХОББИ И ИНТЕРЕСЫ",
    languages: "ЯЗЫКИ",
    certifications: "СЕРТИФИКАТЫ",

    statementText:
      "Предприниматель‑экономист с 20+ годами опыта, превращаю данные в прибыль для торговых и промышленных МСП. Создаю предпосылки для масштабного роста компаний, внедряя различные инструменты управления — такие как организационные структуры, корпоративная идеология и системы учёта. Глубоко знаком с бухгалтерским и управленческим учётом, которые служат основой для построения эффективных процессов. Активно исследую и применяю возможности искусственного интеллекта в бизнесе (Python, n8n, LangChain). Основал и вывел на уровень $150 тыс. оборота в месяц оптово-розничную компанию непродовольственных товаров (15 сотрудников). Ищу возможность масштабировать рост компаний в Скандинавии.",

    workItems: [
      {
        year: "2024-2025",
        title: "Консультант по развитию бизнеса",
        company: "Visotsky Consulting",
        description:
          "Провел 20+ коучинговых сессий для владельцев МСП. Специализация в выявлении и устранении узких мест, препятствующих росту и развитию компаний.",
      },
      {
        year: "2010-2022",
        title: "Собственник / CEO",
        company: "Частное торговое предприятие, Украина",
        description:
          "• Основал торговое предприятие (15 сотрудников, 1000+ SKU)\n• Увеличил оборот до $150,000 в год после ковида\n• Автоматизировал процессы бухгалтерского и управленческого учета с помощью Excel",
      },
      {
        year: "2004-2010",
        title: "Фриланс-консультант",
        company: "Индивидуальный предприниматель в сфере учёта",
        description: "• Внедрял бухгалтерский, управленческий и налоговый учёт для ~15 малых предприятий\n• Оптимизировал налоговую нагрузку — снижение выплат от 15%\n• Консультировал предпринимателей по вопросам учёта, отчётности и налогообложения",
      },
      {
        year: "2006-2007",
        title: "Директор по экспортным продажам",
        company: "LLC AzovElitStroy, Украина",
        description: "Продажи металлопроката и газовых баллонов. Общая сумма контрактов ≈$2 млн.",
      },
      {
        year: "2002-2003",
        title: "Консультант по управленческому учету",
        company: "LLC Selgor-Consult, Украина",
        description: "Внедрение бухгалтерского управленческого учета на Ясиноватском машиностроительном заводе (≈800 сотрудников).",
      },
      {
        year: "2000-2002",
        title: "Бухгалтер, экономист",
        company: "ООО Азов Сталь",
        description: "• Учет и аудит поставок продовольствия/ТМЦ для сети корпоративных столовых (≈200 наименований товаров)\n• Участие в 30 ревизиях сети корпоративных столовых и продовольственных складов",
      },
    ],

    educationItems: [
      {
        year: "2000-2002",
        title: "Аспирантура",
        company: "PSTU",
        description: "Организация планирования и управления экономикой предприятия",
      },
      {
        year: "1999-2000",
        title: "Магистр (SeQF 7)",
        company: "PSTU",
        description: "Экономика предпринимательства",
      },
      {
        year: "1995-1999",
        title: "Бакалавр (SeQF 6)",
        company: "PSTU",
        description: "Экономика",
      },
    ],

    skills: [
      { name: "Автоматизация", level: 90 },
      { name: "Управление", level: 95 },
      { name: "Аналитика", level: 85 },
      { name: "AI инструменты", level: 80 },
      { name: "Коучинг", level: 85 },
      { name: "Python", level: 75 },
      { name: "1C", level: 90 },
    ],

    personalSkillsItems: [
      { name: "Лидерство", level: 5 },
      { name: "Коммуникация", level: 4 },
      { name: "Креативность", level: 4 },
      { name: "Организация", level: 5 },
      { name: "Управление", level: 5 },
    ],

    languageSkills: [
      { name: "Шведский", level: 2 },
      { name: "Английский", level: 4 },
      { name: "Украинский", level: 5 },
      { name: "Русский", level: 5 },
    ],

    certificationItems: [
      "Консультант по развитию бизнеса (Visotsky Consulting, 2024-2025)",
      "Samhällsorientering (Västra Götaland, 2025)",
      "AI-Automation Specialist (n8n, LangChain, ChatGPT API)",
      "Python для бизнес-аналитики",
      "UI/UX & Webbdesign",
    ],
  },

  en: {
    name: "Vladyslav Chyzhov",
    title: "Entrepreneur & Economist",
    downloadPdf: "Download PDF",
    statement: "RESUME",
    workExperience: "WORK EXPERIENCE",
    education: "EDUCATION",
    proSkills: "PROFESSIONAL SKILLS",
    personalSkills: "PERSONAL SKILLS",
    hobbies: "HOBBIES AND INTERESTS",
    languages: "LANGUAGES",
    certifications: "CERTIFICATIONS",

    statementText:
      "Entrepreneur-economist with 20+ years of experience, turning data into profit for trading and industrial SMEs. Creating prerequisites for scalable company growth by implementing various management tools — such as organizational structures, corporate ideology, and accounting systems. Deeply familiar with accounting and management accounting, which serve as the foundation for building efficient processes. Actively exploring and applying artificial intelligence capabilities in business (Python, n8n, LangChain). Founded and brought to $150K monthly turnover a wholesale-retail company of non-food products (15 employees). Seeking opportunity to scale company growth in Scandinavia.",

    workItems: [
      {
        year: "2024-2025",
        title: "Business Development Consultant",
        company: "Visotsky Consulting",
        description:
          "Conducted 20+ coaching sessions for SME owners. Specialization in identifying and eliminating narrow places that hinder company growth and development.",
      },
      {
        year: "2010-2022",
        title: "Owner / CEO",
        company: "Private Trading Enterprise, Ukraine",
        description:
          "• Founded trading enterprise (15 employees, 1000+ SKU)\n• Increased turnover to $150,000 per year after COVID\n• Automated accounting and management accounting processes with 1C (Russian business system, equivalent to Visma) and Excel",
      },
      {
        year: "2004-2010",
        title: "Freelance Consultant",
        company: "Individual Entrepreneur in Accounting",
        description: "• Implemented accounting, management and tax accounting for ~15 small enterprises\n• Optimized tax burden — reduction in payments from 15%\n• Consulted entrepreneurs on accounting, reporting and taxation issues",
      },
      {
        year: "2006-2007",
        title: "Export Sales Director",
        company: "LLC AzovElitStroy, Ukraine",
        description: "Sales of metal products and gas cylinders. Total contract value ≈$2M.",
      },
      {
        year: "2002-2003",
        title: "Management Accounting Consultant",
        company: "LLC Selgor-Consult, Ukraine",
        description: "Implementation of accounting management accounting at Yasynovatsky Machine-Building Plant (≈800 employees).",
      },
      {
        year: "2000-2002",
        title: "Accountant, Economist",
        company: "LLC Azov Steel",
        description: "• Accounting and audit of food supplies/commodities for corporate canteen network (≈200 product items)\n• Participation in 30 audits of corporate canteen network and food warehouses",
      },
    ],

    educationItems: [
      {
        year: "2000-2002",
        title: "PhD Studies",
        company: "PSTU",
        description: "Organization of planning and enterprise economics management",
      },
      {
        year: "1999-2000",
        title: "Master's Degree (SeQF 7)",
        company: "PSTU",
        description: "Business Economics",
      },
      {
        year: "1995-1999",
        title: "Bachelor's Degree (SeQF 6)",
        company: "PSTU",
        description: "Economics",
      },
    ],

    skills: [
      { name: "Automation", level: 90 },
      { name: "Management", level: 95 },
      { name: "Analytics", level: 85 },
      { name: "AI Tools", level: 80 },
      { name: "Coaching", level: 85 },
      { name: "Python", level: 75 },
      { name: "1C", level: 90 },
    ],

    personalSkillsItems: [
      { name: "Leadership", level: 5 },
      { name: "Communication", level: 4 },
      { name: "Creativity", level: 4 },
      { name: "Organization", level: 5 },
      { name: "Management", level: 5 },
    ],

    languageSkills: [
      { name: "Swedish", level: 2 },
      { name: "English", level: 4 },
      { name: "Ukrainian", level: 5 },
      { name: "Russian", level: 5 },
    ],

    certificationItems: [
      "Business Development Consultant (Visotsky Consulting, 2024-2025)",
      "Civic Orientation (Västra Götaland, 2025)",
      "AI-Automation Specialist (n8n, LangChain, ChatGPT API)",
      "Python for Business Analytics",
      "UI/UX & Web Design",
    ],
  },

  sv: {
    name: "Vladyslav Chyzhov",
    title: "Entreprenör & Ekonom",
    downloadPdf: "Ladda ner PDF",
    statement: "CV",
    workExperience: "ARBETSLIVSERFARENHET",
    education: "UTBILDNING",
    proSkills: "PROFESSIONELLA FÄRDIGHETER",
    personalSkills: "PERSONLIGA EGENSKAPER",
    hobbies: "HOBBYER OCH INTRESSEN",
    languages: "SPRÅK",
    certifications: "CERTIFIERINGAR",

    statementText:
      "Entreprenör-ekonom med 20+ års erfarenhet, förvandlar data till vinst för handels- och industriföretag. Skapar förutsättningar för skalbar företagstillväxt genom att implementera olika ledningsverktyg — såsom organisatoriska strukturer, företagsidéologi och redovisningssystem. Djupgående kännedom om bokföring och ekonomistyrning, som utgör grunden för att bygga effektiva processer. Aktivit utforskar och tillämpar artificiell intelligens i affärer (Python, n8n, LangChain). Grundade och drev till $150K månadsomsättning ett grossist-detaljhandelsföretag för icke-livsmedel (15 anställda). Söker möjlighet att skala företagstillväxt i Skandinavien.",

    workItems: [
      {
        year: "2024-2025",
        title: "Affärsutvecklingskonsult",
        company: "Visotsky Consulting",
        description:
          "Genomförde 20+ coachingsessioner för småföretagare. Specialisering inom identifiering och eliminering av trånga ställen som hindrar företagstillväxt och utveckling.",
      },
      {
        year: "2010-2022",
        title: "Ägare / VD",
        company: "Privat handelsföretag, Ukraina",
        description:
          "• Grundade handelsföretag (15 medarbetare, 1000+ artiklar)\n• Ökade omsättningen till $150,000 per år efter COVID\n• Automatiserade bokförings- och ekonomistyrningsprocesser med 1C (ryskt affärssystem, motsvarande Visma) och Excel",
      },
      {
        year: "2004-2010",
        title: "Frilans-konsult",
        company: "Enskild näringsidkare inom redovisning",
        description: "• Implementerade bokföring, ekonomistyrning och skatteredovisning för ~15 småföretag\n• Optimerade skattebördan — minskning av betalningar från 15%\n• Konsulterade företagare inom redovisning, rapportering och beskattning",
      },
      {
        year: "2006-2007",
        title: "Exportförsäljningsdirektör",
        company: "LLC AzovElitStroy, Ukraina",
        description: "Försäljning av metallprodukter och gasflaskor. Totalt kontraktsvärde ≈$2M.",
      },
      {
        year: "2002-2003",
        title: "Ekonomistyrkonsult",
        company: "LLC Selgor-Consult, Ukraina",
        description: "Implementering av bokförings ekonomistyrning på Yasynovatsky Maskinbyggfabrik (≈800 medarbetare).",
      },
      {
        year: "2000-2002",
        title: "Revisor, Ekonom",
        company: "LLC Azov Steel",
        description: "• Bokföring och revision av livsmedelsleveranser/varor för företagskantin nätverk (≈200 produktartiklar)\n• Deltagande i 30 revisioner av företagskantin nätverk och livsmedelslager",
      },
    ],

    educationItems: [
      {
        year: "2000-2002",
        title: "Forskarutbildning",
        company: "PSTU",
        description: "Organisation av planering och företagsekonomisk styrning",
      },
      {
        year: "1999-2000",
        title: "Magisterexamen (SeQF 7)",
        company: "PSTU",
        description: "Företagsekonomi",
      },
      {
        year: "1995-1999",
        title: "Kandidatexamen (SeQF 6)",
        company: "PSTU",
        description: "Ekonomi",
      },
    ],

    skills: [
      { name: "Automatisering", level: 90 },
      { name: "Ledning", level: 95 },
      { name: "Analys", level: 85 },
      { name: "AI-verktyg", level: 80 },
      { name: "Coaching", level: 85 },
      { name: "Python", level: 75 },
      { name: "1C", level: 90 },
    ],

    personalSkillsItems: [
      { name: "Ledarskap", level: 5 },
      { name: "Kommunikation", level: 4 },
      { name: "Kreativitet", level: 4 },
      { name: "Organisation", level: 5 },
      { name: "Ledning", level: 5 },
    ],

    languageSkills: [
      { name: "Svenska", level: 2 },
      { name: "Engelska", level: 4 },
      { name: "Ukrainska", level: 5 },
      { name: "Ryska", level: 5 },
    ],

    certificationItems: [
      "Affärsutvecklingskonsult (Visotsky Consulting, 2024-2025)",
      "Samhällsorientering (Västra Götaland, 2025)",
      "AI-Automationsspecialist (n8n, LangChain, ChatGPT API)",
      "Python för affärsanalys",
      "UI/UX & Webbdesign",
    ],
  },
}

export default function CVPage() {
  const [language, setLanguage] = useState<"ru" | "en" | "sv">("sv")
  const [profilePhoto, setProfilePhoto] = useState<string>("/images/profile-photo.png")

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const photoData = e.target?.result as string
        setProfilePhoto(photoData)
        // Сохраняем в localStorage
        localStorage.setItem('profilePhoto', photoData)
      }
      reader.readAsDataURL(file)
    }
  }

  // Загружаем сохраненную фотографию при инициализации
  useEffect(() => {
    const savedPhoto = localStorage.getItem('profilePhoto')
    if (savedPhoto) {
      setProfilePhoto(savedPhoto)
    }
  }, [])

  const t = translations[language]

  const downloadPDF = async () => {
    const result = await generatePDF({ language })
    
    if (result.success) {
      console.log(`PDF generated successfully: ${result.filename}`)
    } else {
      console.error("PDF generation failed:", result.error)
    }
  }

  const downloadDOCX = async () => {
    const result = await convertCVToDocx()
    
    if (result.success) {
      console.log("DOCX generated successfully")
    } else {
      console.error("DOCX generation failed:", result.error)
    }
  }

  const renderStars = (level: number) => {
    return (
      <div className="flex gap-1">
        {[...Array(5)].map((_, i) => (
          <Star key={i} className={`w-3 h-3 ${i < level ? "fill-sky-400 text-sky-400" : "text-gray-300"}`} />
        ))}
      </div>
    )
  }

  const renderProgressBar = (level: number) => {
    return (
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-sky-400 h-2 rounded-full transition-all duration-300 progress-bar-fill" 
          data-width={level}
        ></div>
      </div>
    )
  }

  return (
    <div className="a4-container font-inter">
      {/* Language Selector & PDF Download Button - Hidden in print */}
      <div className="fixed top-6 right-6 z-10 flex flex-col gap-4 print:hidden">
        <Card className="p-3 bg-white border border-gray-200 rounded-lg shadow-lg">
          <div className="flex items-center gap-3">
            <Languages className="w-4 h-4 text-sky-500" />
            <div className="flex bg-gray-100 rounded-lg overflow-hidden">
              <Button
                variant={language === "sv" ? "default" : "ghost"}
                size="sm"
                onClick={() => setLanguage("sv")}
                className={`rounded-none text-sm px-4 py-2 ${
                  language === "sv" ? "bg-sky-500 text-white hover:bg-sky-600" : "hover:bg-gray-200 text-gray-700"
                }`}
              >
                SV
              </Button>
              <Button
                variant={language === "en" ? "default" : "ghost"}
                size="sm"
                onClick={() => setLanguage("en")}
                className={`rounded-none text-sm px-4 py-2 ${
                  language === "en" ? "bg-sky-500 text-white hover:bg-sky-600" : "hover:bg-gray-200 text-gray-700"
                }`}
              >
                EN
              </Button>
              <Button
                variant={language === "ru" ? "default" : "ghost"}
                size="sm"
                onClick={() => setLanguage("ru")}
                className={`rounded-none text-sm px-4 py-2 ${
                  language === "ru" ? "bg-sky-500 text-white hover:bg-sky-600" : "hover:bg-gray-200 text-gray-700"
                }`}
              >
                RU
              </Button>
            </div>
          </div>
        </Card>

        {/* PDF Download Button */}
        <Button
          onClick={downloadPDF}
          className="bg-sky-500 hover:bg-sky-600 text-white font-medium px-6 py-3 rounded-lg transition-colors duration-200 shadow-lg"
        >
          <Download className="w-4 h-4 mr-2" />
          {t.downloadPdf}
        </Button>

        {/* DOCX Download Button */}
        <Button
          onClick={downloadDOCX}
          className="bg-green-500 hover:bg-green-600 text-white font-medium px-6 py-3 rounded-lg transition-colors duration-200 shadow-lg"
        >
          <Download className="w-4 h-4 mr-2" />
          Download DOCX
        </Button>
      </div>

      {/* Page 1 */}
      <div data-page="1" className="w-[210mm] h-[297mm] mx-auto bg-white print:w-full print:h-auto overflow-hidden">
        <div className="h-full flex flex-col">
          {/* Header Section */}
          <div className="grid grid-cols-5 h-64">
            {/* Photo Section */}
            <div className="col-span-2 bg-sky-100 p-6 flex items-center justify-center relative group rounded-full aspect-square w-48 h-48 mx-auto mt-8">
              <img
                src={profilePhoto || "/placeholder.svg"}
                alt={t.name}
                className="w-full h-full object-cover object-top absolute inset-0 rounded-full"
                crossOrigin="anonymous"
              />
              {/* Photo Upload Button - Hidden in print */}
              <label className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer print:hidden z-10">
                <Upload className="w-6 h-6 text-white" />
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" title="Upload profile photo" />
              </label>
              

            </div>

            {/* Statement and Contact */}
            <div className="col-span-3 p-6">
              <div className="mb-2">
                <h2 className="text-base font-bold text-gray-600 mb-2 tracking-wide">{t.statement}</h2>
                <p className={`text-xs text-gray-700 ${language === "ru" ? "leading-[1.4]" : "leading-[1.6]"}`}>{t.statementText}</p>
              </div>

              {/* Contact Info */}
              <div className={`grid grid-cols-2 gap-3 text-xs ${language === "ru" ? "mt-1" : "mt-4"}`}>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 bg-sky-400 rounded-full flex items-center justify-center">
                      <Globe className="w-2.5 h-2.5 text-white" />
                    </div>
                    <span className="text-gray-700">vladchyzhov.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 bg-sky-400 rounded-full flex items-center justify-center">
                      <Phone className="w-2.5 h-2.5 text-white" />
                    </div>
                    <span className="text-gray-700">+46 76 247 5916</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 bg-sky-400 rounded-full flex items-center justify-center">
                      <Mail className="w-2.5 h-2.5 text-white" />
                    </div>
                    <span className="text-gray-700">vlad.chyzhov78@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 bg-sky-400 rounded-full flex items-center justify-center">
                      <MapPin className="w-2.5 h-2.5 text-white" />
                    </div>
                    <span className="text-gray-700">Stenungsund, Sverige</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Name Section */}
          <div className="w-full bg-sky-500/40 backdrop-blur-sm h-20 mt-2">
            <h1 className="px-6 py-2 text-white text-2xl font-bold uppercase">
              {t.name}
            </h1>
            <p className="px-6 pb-2 text-white text-sm opacity-90">
              {t.title}
            </p>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-5 flex-1">
            {/* Left Column */}
            <div className="col-span-3 p-6 space-y-6">
              {/* Work Experience */}
              <div>
                <div className="flex items-center gap-3 mb-4 pl-4">
                  <div className="w-8 h-8 bg-sky-400 rounded-full flex items-center justify-center">
                    <Briefcase className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-sky-400 tracking-wide">{t.workExperience}</h2>
                </div>

                <div className="space-y-4">
                  {t.workItems.slice(0, 6).map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="flex flex-col items-center w-16">
                        <div className="text-xs font-bold text-gray-600">{item.year}</div>
                        <div className="w-2.5 h-2.5 bg-sky-400 rounded-full mt-1"></div>
                        {index < 5 && <div className="w-0.5 h-12 bg-sky-200 mt-1"></div>}
                      </div>
                      <div className="flex-1 -mt-1">
                        <h3 className="font-bold text-gray-800 text-sm mb-2">{item.title}</h3>
                        <p className="text-xs text-gray-400 mb-3 font-medium">{item.company}</p>
                        <div className="text-xs text-gray-700 leading-relaxed whitespace-pre-line">{item.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>


            </div>

            {/* Right Column */}
            <div className="col-span-2 p-6 space-y-6">
              {/* Professional Skills */}
              <div className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
                <h2 className="text-base font-bold text-sky-400 mb-4 tracking-wide">{t.proSkills}</h2>
                <div className="space-y-3">
                  {t.skills.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs text-gray-700">{skill.name}</span>
                      </div>
                      {renderProgressBar(skill.level)}
                    </div>
                  ))}
                </div>
              </div>

              {/* Personal Skills */}
              <div className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
                <h2 className="text-base font-bold text-sky-400 mb-4 tracking-wide">{t.personalSkills}</h2>
                <div className="space-y-3">
                  {t.personalSkillsItems.map((skill, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-xs text-gray-700">{skill.name}</span>
                      {renderStars(skill.level)}
                    </div>
                  ))}
                </div>
              </div>

              {/* Languages */}
              <div className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
                <h2 className="text-base font-bold text-sky-400 mb-4 tracking-wide">{t.languages}</h2>
                <div className="space-y-3">
                  {t.languageSkills.map((skill, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-xs text-gray-700">{skill.name}</span>
                      {renderStars(skill.level)}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Page 2 */}
      <div
        data-page="2"
        className="w-[210mm] h-[297mm] mx-auto bg-white print:w-full print:h-auto print:break-before-page overflow-hidden"
      >
        <div className="h-full">
          {/* Main Content */}
          <div className="grid grid-cols-5 h-full">
            {/* Left Column */}
            <div className="col-span-3 p-6 space-y-6">
              {/* Education */}
              <div>
                <div className="flex items-center gap-3 mb-4 pl-4">
                  <div className="w-8 h-8 bg-sky-400 rounded-full flex items-center justify-center">
                    <GraduationCap className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-sky-400 tracking-wide">{t.education}</h2>
                </div>

                <div className="space-y-4">
                  {t.educationItems.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="flex flex-col items-center w-16">
                        <div className="text-xs font-bold text-gray-600">{item.year}</div>
                        <div className="w-2.5 h-2.5 bg-sky-400 rounded-full mt-1"></div>
                        {index < t.educationItems.length - 1 && <div className="w-0.5 h-12 bg-sky-200 mt-1"></div>}
                      </div>
                      <div className="flex-1 -mt-1">
                        <h3 className="font-bold text-gray-800 text-sm mb-2">{item.title}</h3>
                        <p className="text-xs text-gray-400 mb-3 font-medium">{item.company}</p>
                        <div className="text-xs text-gray-700 leading-relaxed whitespace-pre-line">{item.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>



              {/* Certifications */}
              <div>
                <div className="flex items-center gap-3 mb-4 pl-4">
                  <div className="w-8 h-8 bg-sky-400 rounded-full flex items-center justify-center">
                    <GraduationCap className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-sky-400 tracking-wide">{t.certifications}</h2>
                </div>

                <div className="space-y-2">
                  {t.certificationItems.map((item, index) => (
                    <div key={index} className="flex items-start gap-4 pl-7">
                      <div className="w-1.5 h-1.5 bg-sky-400 rounded-full mt-1.5 flex-shrink-0"></div>
                      <p className="text-xs text-gray-700 leading-relaxed">{item}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Hobbies */}
              <div>
                <div className="flex items-center gap-3 mb-4 pl-4">
                  <div className="w-8 h-8 bg-sky-400 rounded-full flex items-center justify-center">
                    <Heart className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-sky-400 tracking-wide">{t.hobbies}</h2>
                </div>

                <div className="grid grid-cols-5 gap-4">
                  <div className="text-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <Activity className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-600">
                      {language === "sv" ? "Sport" : language === "en" ? "Sport" : "Спорт"}
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <Users className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-600">
                      {language === "sv" ? "Familj" : language === "en" ? "Family" : "Семья"}
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <Code className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-600">
                      {language === "sv" ? "Kodning" : language === "en" ? "Coding" : "koding"}
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <Brain className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-600">
                      {language === "sv" ? "AI" : language === "en" ? "AI" : "ИИ"}
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <BookOpen className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-600">
                      {language === "sv" ? "Läsning" : language === "en" ? "Reading" : "Чтение"}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="col-span-2 p-6 space-y-6">

              {/* Key Achievements */}
              <div className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
                <h2 className="text-base font-bold text-sky-400 mb-4 tracking-wide">
                  {language === "sv"
                    ? "NYCKELRESULTAT"
                    : language === "en"
                      ? "KEY ACHIEVEMENTS"
                      : "КЛЮЧЕВЫЕ ДОСТИЖЕНИЯ"}
                </h2>
                <div className="space-y-3">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold text-sky-400">50%</div>
                    <div className="text-xs text-gray-600">
                      {language === "sv"
                        ? "Team Effektivitetsökning"
                        : language === "en"
                          ? "Team Efficiency Increase"
                          : "Рост эффективности команды"}
                    </div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold text-sky-400">20+</div>
                    <div className="text-xs text-gray-600">
                      {language === "sv" ? "År entreprenörserfarenhet" : language === "en" ? "Years Entrepreneurship" : "Лет предпринимательства"}
                    </div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold text-sky-400">$150K</div>
                    <div className="text-xs text-gray-600">
                      {language === "sv" ? "Månadsomsättning" : language === "en" ? "Monthly Turnover" : "Оборот в месяц"}
                    </div>
                  </div>
                </div>
              </div>

              {/* Values */}
              <div className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
                <h2 className="text-base font-bold text-sky-400 mb-4 tracking-wide">
                  {language === "sv" ? "VÄRDEN" : language === "en" ? "VALUES" : "ЦЕННОСТИ"}
                </h2>
                <div className="space-y-3">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-bold text-sky-400">
                      {language === "ru" ? (
                        <>
                          <div>Lagom</div>
                          <div className="text-xs text-gray-600 mt-1 font-normal">Баланс и умеренность</div>
                        </>
                      ) : (
                        "Lagom"
                      )}
                    </div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-bold text-sky-400">
                      {language === "ru" ? (
                        <>
                          <div>Work-life balance</div>
                          <div className="text-xs text-gray-600 mt-1 font-normal">Устойчивая рабочая среда</div>
                        </>
                      ) : (
                        "Work-life balance"
                      )}
                    </div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-bold text-sky-400">
                      {language === "ru" ? (
                        <>
                          <div>Lifelong learning</div>
                          <div className="text-xs text-gray-600 mt-1 font-normal">Непрерывное развитие</div>
                        </>
                      ) : (
                        "Lifelong learning"
                      )}
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
